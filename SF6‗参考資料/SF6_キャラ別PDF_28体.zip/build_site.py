#!/usr/bin/env python3
"""data/*.json から SF6 攻略ガイドのキャラ紹介ページ（html/character-{key}.html）を生成する。
ベース：character-cviper.html と同じ構造・クラス名（style.css / script.js をそのまま利用）。"""
import json, html, re
from pathlib import Path

ROOT = Path(__file__).parent
DATA = ROOT / "data"
SITE = Path("/home/claude/sf6-site")
OUTDIR = SITE / "html"
VER = "20261010"

ORDER = ["ken", "ryu", "jamie", "chunli", "guile", "kimberly", "juri", "blanka", "ehonda",
         "deejay", "manon", "marisa", "jp", "zangief", "lily", "cammy", "rashid", "aki", "ed",
         "akuma", "mbison", "terry", "mai", "elena", "sagat", "alex", "ingrid", "yasmin"]

# ヒーロー欄の TYPE / DIFFICULTY（動画の解説内容から設定。必要なら編集してください）
PROFILE = {
    "ken": ("万能・ラッシュ攻め", 2), "ryu": ("スタンダード・弾", 2), "jamie": ("成長型（飲酒）", 4),
    "chunli": ("差し合い・高火力", 5), "guile": ("待ち・対応型", 3), "kimberly": ("接近・ラッシュ", 3),
    "juri": ("差し合い・ラッシュ", 3), "blanka": ("セットプレイ", 2), "ehonda": ("突進・投げ択", 2),
    "deejay": ("強襲・ラッシュ", 3), "manon": ("投げキャラ", 2), "marisa": ("高火力・一撃", 3),
    "jp": ("遠距離・設置", 4), "zangief": ("投げキャラ", 3), "lily": ("投げキャラ", 2),
    "cammy": ("接近・持続当て", 3), "rashid": ("トリッキー・機動力", 4), "aki": ("毒・セットプレイ", 5),
    "ed": ("中距離・差し合い", 3), "akuma": ("画面端特化・高火力", 4), "mbison": ("ラッシュ・攻め", 3),
    "terry": ("必殺技で展開作り", 3), "mai": ("ラッシュ・連携", 3), "elena": ("地上戦・確認型", 4),
    "sagat": ("リーチ・高火力", 3), "alex": ("打撃寄り投げキャラ", 3), "ingrid": ("ストック管理・高火力", 4),
    "yasmin": ("ラッシュ・強化型", 4),
}
# 画像の位置調整（既定値。キャラごとに HTML 上の style で変更可能）
MEDIA_STYLE = "--img-y: 15%; --img-zoom: 1; --img-shift: 0px; --fade-top: 18%; --fade-bottom: 45%; --fade-left: 14%; --fade-right: 14%;"

COMBO_CATS = [("enders", "締めパーツ", "コンボ後半の締めルート。以降のコンボの最後に付ける。"),
              ("light", "小技始動", "差し合いや暴れ潰しで小技が当たった時のコンボ。"),
              ("medium", "中攻撃始動", "中攻撃（置き・差し返し）が当たった時のコンボ。"),
              ("heavy", "強攻撃始動", "確定反撃や強攻撃ヒット時のコンボ。"),
              ("counter", "カウンター", "カウンターヒットした時の追撃。"),
              ("punish", "パニカン", "パニッシュカウンター・確定反撃時の高火力コンボ。"),
              ("impact", "インパクト", "ドライブインパクトがヒットした時のコンボ。"),
              ("sa_use", "SAゲージ活用", "SAゲージを使ってダメージを伸ばすコンボ。"),
              ("sa_build", "SAゲージ回収", "SAゲージの回収を優先するコンボ。")]

MOVES = json.loads((DATA / "moves.json").read_text())


def e(s):
    return html.escape(str(s or ""), quote=True)


def cmd_chain(s):
    """「A → B → C」を .cmd チップ＋›区切りに変換"""
    parts = [p.strip() for p in re.split(r"\s+→\s+", s or "") if p.strip()]
    if not parts:
        return ""
    sep = '<span class="arrow" aria-hidden="true">›</span>'
    return sep.join(f'<span class="cmd">{e(p)}</span>' for p in parts)


def ul(items):
    items = [x for x in (items or []) if x]
    if not items:
        return '<p style="color:var(--text-dim)">動画内で紹介なし</p>'
    return '<ul class="list">' + "".join(f"<li>{e(x)}</li>" for x in items) + "</ul>"


def dash():
    return '<span style="color:var(--text-dim)">—</span>'


def overview(d):
    ov = d["overview"]
    return f"""
          <h3>ODゲージがある時</h3>
          {ul(ov.get('od_on'))}
          <h3>ODゲージがない時</h3>
          {ul(ov.get('od_off'))}
          <h3>差し合い</h3>
          {ul(ov.get('neutral'))}
          <h3>対空</h3>
          {ul(ov.get('anti_air'))}
          <h3>画面端</h3>
          {ul(ov.get('corner'))}
          <div class="pros-cons">
            <div class="pros"><h4>強み</h4>{ul(ov.get('strengths'))}</div>
            <div class="cons"><h4>弱み</h4>{ul(ov.get('weaknesses'))}</div>
          </div>"""


def moves(key):
    rows = MOVES.get(key, [])
    trs = "".join(f'<tr><td><b>{e(m["name"])}</b></td><td><span class="cmd">{e(m["command"])}</span></td>'
                  f'<td>{e(m.get("note")) or "—"}</td></tr>' for m in rows)
    return f"""<div class="table-wrap"><table class="data-table">
            <thead><tr><th>技名</th><th>コマンド</th><th>備考</th></tr></thead>
            <tbody>{trs}</tbody>
          </table></div>"""


def combo_card(c):
    note = f'<p class="combo-note">{e(c["note"])}</p>' if c.get("note") else ""
    start = re.split(r"\s+→\s+", c.get("cmd") or "")[0]
    cid = re.sub(r"[^a-z0-9]", "-", c["id"].lower())
    return f"""
              <article class="combo-card" id="cb-{cid}">
                <div class="combo-top"><span class="combo-id">{e(c['id'])}</span><h4 class="combo-recipe">{e(c['name'])}</h4></div>
                <div class="combo-cmd">{cmd_chain(c.get('cmd'))}</div>
                {'' if start.startswith('…') else f'<div class="combo-stats"><span>始動 <b>{e(start)}</b></span></div>'}
                {note}
              </article>"""


def combos(d):
    cats = [(k, label, desc, d["combos"].get(k) or []) for k, label, desc in COMBO_CATS]
    filled = [c for c in cats if c[3]]
    empty = [c[1] for c in cats if not c[3]]
    if not filled:
        return ('<div class="callout callout--warn">参考動画ではコンボレシピが紹介されていません。'
                '立ち回り・生ラッシュ・セットプレイの項目を参考にしてください。</div>')
    btns = "".join(
        f'<button type="button" role="tab" class="tab-btn" id="tab-{k}" aria-controls="combo-{k}" aria-selected="false">'
        f'{e(label)}<span class="count">{len(items)}</span></button>' for k, label, _, items in filled)
    panels = "".join(f"""
          <div class="tab-panel" role="tabpanel" id="combo-{k}" aria-labelledby="tab-{k}" hidden>
            <p class="tab-desc">{e(desc)}</p>
            <div class="combo-list">{''.join(combo_card(c) for c in items)}
            </div>
          </div>""" for k, label, desc, items in filled)
    note = (f'<div class="callout">動画内で紹介なし：{e("／".join(empty))}</div>' if empty else "")
    return f"""
          <p>始動技の種類ごとにタブで切り替えられます。コマンドは「›」の順に入力します。</p>
          <div class="tabs" data-tabs id="comboTabs">
            <div class="tab-list" role="tablist" aria-label="コンボの分類">{btns}</div>{panels}
          </div>
          {note}"""


def rush(d):
    items = d.get("rush") or []
    if not items:
        return '<div class="callout">参考動画では生ラッシュのコンボ・行動の紹介はありません。</div>'
    trs = "".join(
        f'<tr><td class="num">{e(r["id"])}</td><td><b>{e(r["name"])}</b></td><td>{cmd_chain(r["cmd"])}</td>'
        f'<td class="num">{("<span>" + e(r["adv"]) + "</span>") if r.get("adv") else dash()}</td><td>{e(r.get("note")) or "—"}</td></tr>'
        for r in items)
    return f"""<div class="table-wrap"><table class="data-table" style="min-width:780px">
            <thead><tr><th style="width:56px">ID</th><th style="width:170px">行動</th><th>コマンド</th><th style="width:120px">有利F</th><th>摘要</th></tr></thead>
            <tbody>{trs}</tbody>
          </table></div>"""


def setplay(d):
    items = d.get("setplay") or []
    if not items:
        return '<div class="callout">参考動画ではセットプレイ・起き攻めの紹介はありません。</div>'
    trs = "".join(
        f'<tr><td class="num">{e(s["id"])}</td><td>{e(s["start"])}</td><td>{e(s.get("route")) or "—"}</td>'
        f'<td>{cmd_chain(s["cmd"])}</td>'
        f'<td class="num">{("<span>" + e(s["adv"]) + "</span>") if s.get("adv") else "<span style=\"color:var(--text-dim)\">（数値表記なし）</span>"}</td>'
        f'<td>{e(s.get("meaty")) or "—"}</td><td>{e(s.get("note")) or "—"}</td></tr>'
        for s in items)
    return f"""<p>起点（締めや状況）ごとに、その後の行動・有利フレーム・重ねる技をまとめています。</p>
          <div class="table-wrap"><table class="data-table" style="min-width:1100px">
            <thead><tr><th style="width:56px">ID</th><th style="width:190px">起点（締め）</th><th style="width:170px">その後の行動</th><th style="width:230px">コマンド</th><th style="width:120px">有利F</th><th style="width:140px">重ね技</th><th>摘要</th></tr></thead>
            <tbody>{trs}</tbody>
          </table></div>
          <div class="callout">「数値表記なし」は動画内で有利Fが示されていない連携です。トレーニングモードのフレームメーターで計測して追記してください。</div>"""


def source(d):
    s = d["source"]
    terms = d.get("terms") or []
    trs = "".join(f"<tr><td><b>{e(a)}</b></td><td>{e(b)}</td></tr>" for a, b in terms)
    terms_html = (f"""<h3>動画内用語</h3>
          <div class="table-wrap"><table class="data-table" style="min-width:0">
            <thead><tr><th>用語</th><th>意味</th></tr></thead>
            <tbody>{trs}</tbody>
          </table></div>""" if terms else "")
    notes = d.get("notes") or []
    notes_html = (f"""<h3>摘要（字幕・補足）</h3>
          {ul([re.sub(r'^【摘要[^】]*】', '', n) for n in notes])}""" if notes else "")
    return f"""<p>このページの内容は、以下の解説動画の内容を整理したものです（{e(s['control'])}）。技コマンドはCAPCOM公式コマンドリスト（クラシック）で確認しています。</p>
          <div class="info-grid">
            <a class="info-card" data-accent="pink" href="{e(s['url'])}" target="_blank" rel="noopener">
              <p class="info-label">YOUTUBE ／ {e(s['length'])}</p>
              <p class="info-title">{e(s['title'])}</p>
              <p>投稿者：{e(s['channel'])}</p>
            </a>
          </div>
          {terms_html}
          {notes_html}"""


def page(d, prev_d, next_d):
    key, name, en = d["key"], d["name"], d["en"]
    typ, diff = PROFILE.get(key, ("—", 3))
    n_combo = sum(len(d["combos"].get(k) or []) for k, *_ in COMBO_CATS)
    n_link = len(d.get("rush") or []) + len(d.get("setplay") or [])
    meter = "".join('<i class="on"></i>' if i < diff else "<i></i>" for i in range(5))
    diff_label = {1: "低い", 2: "やや低め", 3: "ふつう", 4: "やや高め", 5: "高い"}[diff]
    label = name.replace(".", "")[:2]
    lead = d["concept"]
    desc = f"{name}の立ち回り方針、技コマンド、コンボ、生ラッシュ、セットプレイ（有利フレーム・重ね技）。"
    pager_next = (f'<a href="character-{next_d["key"]}.html" class="pager-link pager-link--next"><small>NEXT →</small><span>{e(next_d["name"])}</span></a>'
                  if next_d else '<a href="#combos" class="pager-link pager-link--next"><small>JUMP →</small><span>コンボを見る</span></a>')
    pager_prev = (f'<a href="character-{prev_d["key"]}.html" class="pager-link"><small>← PREV</small><span>{e(prev_d["name"])}</span></a>'
                  if prev_d else '<a href="characters.html" class="pager-link"><small>← BACK</small><span>キャラクター選択へ戻る</span></a>')
    return f"""<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{e(name)}（キャラクター詳細） | SF6 攻略ガイド</title>
  <meta name="description" content="{e(desc)}">
  <meta name="theme-color" content="#050508">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Dela+Gothic+One&family=Chakra+Petch:wght@500;700&family=Noto+Sans+JP:wght@400;500;700;900&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="../style.css?v={VER}">
</head>
<body>

  <div class="bg-fx" aria-hidden="true">
    <div class="bg-grid"></div>
    <div class="bg-splash bg-splash--purple"></div>
    <div class="bg-splash bg-splash--cyan"></div>
    <div class="bg-splash bg-splash--pink"></div>
    <div class="bg-noise"></div>
  </div>

  <!-- ===== 共通ヘッダー ===== -->
  <header class="site-header" id="siteHeader">
    <div class="header-inner">
      <a href="../index.html" class="logo" aria-label="SF6 攻略ガイド トップへ">
        <span class="logo-mark" aria-hidden="true">
          <svg viewBox="0 0 40 40"><path d="M6 30 L18 6 L22 16 L34 10 L24 34 L20 24 Z"/></svg>
        </span>
        <span class="logo-text">
          <span class="logo-main">SF6</span>
          <span class="logo-sub">攻略ガイド</span>
        </span>
      </a>
      <button class="menu-btn" id="menuBtn" type="button"
              aria-controls="drawer" aria-expanded="false" aria-label="メニューを開く">
        <span class="menu-btn-label">MENU</span>
        <span class="menu-btn-lines" aria-hidden="true"><span></span><span></span><span></span></span>
      </button>
    </div>
  </header>

  <!-- ===== ドロワーメニュー ===== -->
  <div class="drawer-overlay" id="drawerOverlay" hidden></div>
  <nav class="drawer" id="drawer" aria-label="サイトメニュー" aria-hidden="true">
    <div class="drawer-head">
      <span class="drawer-title">MENU</span>
      <button class="drawer-close" id="drawerClose" type="button" aria-label="メニューを閉じる">
        <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 5 L19 19 M19 5 L5 19"/></svg>
      </button>
    </div>
    <ol class="drawer-list">
      <li><a href="../index.html" class="drawer-link"><span class="drawer-no">00</span><span class="drawer-name">トップページ</span><span class="drawer-en">HOME</span></a></li>
      <li><a href="rules.html" class="drawer-link"><span class="drawer-no">01</span><span class="drawer-name">ゲームルール</span><span class="drawer-en">RULES</span></a></li>
      <li><a href="modes.html" class="drawer-link"><span class="drawer-no">02</span><span class="drawer-name">各モードの遊び方</span><span class="drawer-en">MODES</span></a></li>
      <li><a href="ranks.html" class="drawer-link"><span class="drawer-no">03</span><span class="drawer-name">ランクについて</span><span class="drawer-en">RANK</span></a></li>
      <li><a href="controls.html" class="drawer-link"><span class="drawer-no">04</span><span class="drawer-name">基本操作方法</span><span class="drawer-en">CONTROLS</span></a></li>
      <li><a href="characters.html" class="drawer-link is-current" aria-current="page"><span class="drawer-no">05</span><span class="drawer-name">キャラクター選択</span><span class="drawer-en">CHARACTERS</span></a></li>
      <li><a href="history.html" class="drawer-link"><span class="drawer-no">06</span><span class="drawer-name">ストリートファイターの歴史</span><span class="drawer-en">HISTORY</span></a></li>
      <li><a href="diary.html" class="drawer-link"><span class="drawer-no">07</span><span class="drawer-name">投稿主の日記</span><span class="drawer-en">DIARY</span></a></li>
    </ol>
  </nav>

  <main class="main" id="main">

    <!-- データ元：sf6-pdf/data/{key}.json（{e(name)} 立ち回り＆コンボ資料） -->
    <section class="chara-hero">
      <div>
        <nav class="breadcrumb reveal" aria-label="パンくずリスト">
          <a href="../index.html">TOP</a><span aria-hidden="true">/</span>
          <a href="characters.html">キャラクター選択</a><span aria-hidden="true">/</span><span>{e(name)}</span>
        </nav>
        <p class="chara-name-en reveal" aria-hidden="true">{e(en)}</p>
        <h1 class="page-title reveal">{e(name)}</h1>
        <p class="page-lead reveal">{e(lead)}</p>
        <div class="chara-stats reveal">
          <div class="chara-stat"><small>TYPE</small><b>{e(typ)}</b></div>
          <div class="chara-stat"><small>DIFFICULTY</small><b>{diff_label}</b><div class="meter" aria-label="難易度 5段階中{diff}">{meter}</div></div>
          <div class="chara-stat"><small>DATA</small><b>コンボ{n_combo}・連携{n_link}</b></div>
        </div>
      </div>
      <!-- 画像の位置・フェードは style の値で調整できます -->
      <figure class="media reveal" style="{MEDIA_STYLE}">
        <div class="media-frame" data-label="{e(label)}"><img src="../images/characters/{key}.png" alt="{e(name)}" loading="lazy"></div>
      </figure>
    </section>

    <div class="page-layout">
      <aside class="toc" aria-label="このページの目次">
        <p class="toc-title">INDEX</p>
        <nav><ol>
            <li><a href="#overview">概要・立ち回り方針</a></li>
            <li><a href="#moves">技・コマンド</a></li>
            <li><a href="#combos">コンボ</a></li>
            <li><a href="#rush">生ラッシュ行動</a></li>
            <li><a href="#setplay">セットプレイ・起き攻め</a></li>
            <li><a href="#source">出典・用語</a></li>
        </ol></nav>
      </aside>

      <article class="article">

        <!-- ① 概要・立ち回り -->
        <section class="doc-section reveal" id="overview">
          <div class="sec-head"><span class="sec-no">01</span><h2 class="sec-title">概要・立ち回り方針</h2><span class="sec-en">OVERVIEW</span></div>
{overview(d)}
        </section>

        <!-- ② 技 -->
        <section class="doc-section reveal" id="moves">
          <div class="sec-head"><span class="sec-no">02</span><h2 class="sec-title">技・コマンド（クラシック）</h2><span class="sec-en">MOVES</span></div>
          <p>公式コマンドリストで確認したコマンドです。（溜め）＝溜め入力、一回転＝レバー1回転。</p>
          {moves(key)}
        </section>

        <!-- ③ コンボ -->
        <section class="doc-section reveal" id="combos">
          <div class="sec-head"><span class="sec-no">03</span><h2 class="sec-title">コンボ</h2><span class="sec-en">COMBOS</span></div>
{combos(d)}
        </section>

        <!-- ④ 生ラッシュ -->
        <section class="doc-section reveal" id="rush">
          <div class="sec-head"><span class="sec-no">04</span><h2 class="sec-title">よく使う生ラッシュ行動</h2><span class="sec-en">DRIVE RUSH</span></div>
          {rush(d)}
        </section>

        <!-- ⑤ セットプレイ -->
        <section class="doc-section reveal" id="setplay">
          <div class="sec-head"><span class="sec-no">05</span><h2 class="sec-title">セットプレイ・起き攻め</h2><span class="sec-en">SET PLAY</span></div>
          {setplay(d)}
        </section>

        <!-- ⑥ 出典・用語 -->
        <section class="doc-section reveal" id="source">
          <div class="sec-head"><span class="sec-no">06</span><h2 class="sec-title">出典・用語</h2><span class="sec-en">SOURCE</span></div>
          {source(d)}
        </section>

        <nav class="page-pager" aria-label="前後のページ">
          {pager_prev}
          {pager_next}
        </nav>
      </article>
    </div>

  </main>

  <footer class="site-footer">
    <p class="footer-logo">SF6 攻略ガイド</p>
    <p class="footer-note">本サイトは非公式のファンサイトです。ゲーム内の名称・データの権利は各権利者に帰属します。</p>
  </footer>

  <script src="../script.js?v={VER}"></script>
</body>
</html>
"""


def update_characters_html():
    p = OUTDIR / "characters.html"
    s = p.read_text()
    s = s.replace('href="character-template.html" class="char-card"', 'href="character-ryu.html" class="char-card"')
    for key in ORDER:
        pat = re.compile(r'(<a href="character-' + key + r'\.html" class="char-card"[^>]*?data-status=")(\w+)("[^>]*>\s*<span class="media-frame"[^>]*>.*?</span>\s*<span class="char-year">[^<]*</span>)(<span class="char-badge">COMBO</span>)?', re.S)
        s, n = pat.subn(lambda m: m.group(1) + "ready" + m.group(3) + '<span class="char-badge">COMBO</span>', s)
        assert n == 1, key
    p.write_text(s)


def main():
    chars = [json.loads((DATA / f"{k}.json").read_text()) for k in ORDER]
    for i, d in enumerate(chars):
        prev_d = chars[i - 1] if i > 0 else None
        next_d = chars[i + 1] if i + 1 < len(chars) else None
        (OUTDIR / f"character-{d['key']}.html").write_text(page(d, prev_d, next_d))
    update_characters_html()
    print("generated", len(chars))


if __name__ == "__main__":
    main()
